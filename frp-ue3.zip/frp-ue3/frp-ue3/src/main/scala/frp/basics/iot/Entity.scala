package frp.basics.iot

trait Entity(entityId: Int):
  val id: Int = entityId