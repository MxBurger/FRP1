package frp.basics.iot

import akka.NotUsed
import akka.actor.typed.scaladsl.AskPattern.*
import akka.actor.typed.{ActorRef, ActorSystem}
import akka.stream.scaladsl.Flow
import akka.util.Timeout
import frp.basics.DefaultActorSystem
import frp.basics.MeasureUtil.measure

import scala.annotation.unused
import scala.concurrent.duration.{Duration, DurationInt}
import scala.concurrent.{Await, ExecutionContext, Future}


@main
def ioTApp(): Unit =
  val NR_MESSAGES = 200
  val MESSAGES_PER_SECOND = 100
  val PARALLELISM = 4 // Runtime.getRuntime.availableProcessors
  val BULK_SIZE = 1
  val TIME_WINDOW = 200.millis

  val actorSystem: ActorSystem[DatabaseActor.Command] =
    DefaultActorSystem(DatabaseActor(BULK_SIZE, TIME_WINDOW, PARALLELISM))
  given ExecutionContext = actorSystem.executionContext

  def identityService(): Flow[String, String, NotUsed] = ???

  def simpleMeasurementsService(parallelism: Int = PARALLELISM): Flow[String, String, NotUsed] = ???

  def measurementsServiceWithActor(dbActor: ActorRef[DatabaseActor.Command], parallelism: Int = PARALLELISM): Flow[String, String, NotUsed] = ???

  def measurementsService(parallelism: Int = PARALLELISM): Flow[String, String, NotUsed] = ???

  Await.ready(DefaultActorSystem.terminate(), Duration.Inf)
end ioTApp